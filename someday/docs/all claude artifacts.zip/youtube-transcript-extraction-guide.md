# YouTube Transcript Extraction for Sara's Content
# Someday Consultants Knowledge Base

## Prerequisites

```bash
# Install yt-dlp (better than youtube-dl, actively maintained)
pip install yt-dlp

# Optional: Install whisper for better transcription if YouTube captions are bad
pip install openai-whisper
```

## Step 1: Get All Video URLs from Channel

```bash
# List all videos from channel (just URLs)
yt-dlp --flat-playlist --print url "https://www.youtube.com/@dealmakerseta" > video_urls.txt

# Count how many videos
wc -l video_urls.txt
```

## Step 2: Download All Auto-Generated Transcripts

```bash
# Create output directory
mkdir -p transcripts

# Download only subtitles/captions for all videos (no video download)
yt-dlp \
  --write-auto-sub \
  --sub-lang en \
  --skip-download \
  --sub-format vtt \
  -o "transcripts/%(upload_date)s-%(title)s.%(ext)s" \
  "https://www.youtube.com/@dealmakerseta"
```

This will create files like:
- `transcripts/20240115-How to Value an Accounting Firm.en.vtt`
- `transcripts/20240203-Earnout Structures Explained.en.vtt`

## Step 3: Convert VTT to Clean Text

VTT files have timestamps and formatting. Here's a Python script to clean them:

```python
#!/usr/bin/env python3
"""
clean_transcripts.py
Converts VTT subtitle files to clean text transcripts
"""

import os
import re
from pathlib import Path

def clean_vtt(vtt_content):
    """Remove VTT formatting, timestamps, and duplicates"""
    lines = vtt_content.split('\n')
    
    # Skip header
    text_lines = []
    seen = set()
    
    for line in lines:
        # Skip timestamps, WEBVTT header, positioning info
        if re.match(r'^\d{2}:\d{2}', line):
            continue
        if line.startswith('WEBVTT'):
            continue
        if 'align:' in line or 'position:' in line:
            continue
        if line.strip() == '':
            continue
        if '-->' in line:
            continue
            
        # Remove HTML-like tags
        clean_line = re.sub(r'<[^>]+>', '', line)
        clean_line = clean_line.strip()
        
        # Skip duplicates (VTT often repeats lines)
        if clean_line and clean_line not in seen:
            seen.add(clean_line)
            text_lines.append(clean_line)
    
    # Join into paragraphs (rough paragraph breaks every ~10 sentences)
    full_text = ' '.join(text_lines)
    
    # Clean up extra spaces
    full_text = re.sub(r'\s+', ' ', full_text)
    
    return full_text

def process_directory(input_dir, output_dir):
    """Process all VTT files in directory"""
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    for vtt_file in input_path.glob('*.vtt'):
        print(f"Processing: {vtt_file.name}")
        
        with open(vtt_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        clean_text = clean_vtt(content)
        
        # Output filename: same name but .txt
        output_file = output_path / vtt_file.name.replace('.en.vtt', '.txt').replace('.vtt', '.txt')
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(clean_text)
        
        print(f"  -> {output_file.name} ({len(clean_text)} chars)")

if __name__ == '__main__':
    process_directory('transcripts', 'transcripts_clean')
    print("\nDone! Clean transcripts in transcripts_clean/")
```

Run it:
```bash
python clean_transcripts.py
```

## Step 4: Create Master Document

```python
#!/usr/bin/env python3
"""
combine_transcripts.py
Combines all transcripts into a single searchable document
"""

from pathlib import Path
import json
from datetime import datetime

def combine_transcripts(input_dir, output_file):
    """Combine all transcripts with metadata"""
    input_path = Path(input_dir)
    
    documents = []
    
    for txt_file in sorted(input_path.glob('*.txt')):
        filename = txt_file.stem
        
        # Try to parse date from filename (YYYYMMDD-Title format)
        date_str = filename[:8] if filename[:8].isdigit() else None
        title = filename[9:] if date_str else filename
        
        with open(txt_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        doc = {
            'filename': txt_file.name,
            'title': title.replace('-', ' ').replace('_', ' '),
            'date': date_str,
            'content': content,
            'word_count': len(content.split()),
            'char_count': len(content)
        }
        documents.append(doc)
        print(f"Added: {doc['title'][:50]}... ({doc['word_count']} words)")
    
    # Save as JSON (easy to load into vector DB later)
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(documents, f, indent=2)
    
    # Also create a single markdown file for easy reading
    md_output = output_file.replace('.json', '.md')
    with open(md_output, 'w', encoding='utf-8') as f:
        f.write("# Sara's YouTube Content - Full Transcripts\n\n")
        f.write(f"Generated: {datetime.now().isoformat()}\n")
        f.write(f"Total videos: {len(documents)}\n")
        f.write(f"Total words: {sum(d['word_count'] for d in documents):,}\n\n")
        f.write("---\n\n")
        
        for doc in documents:
            f.write(f"## {doc['title']}\n")
            if doc['date']:
                f.write(f"*Date: {doc['date'][:4]}-{doc['date'][4:6]}-{doc['date'][6:8]}*\n\n")
            f.write(doc['content'])
            f.write("\n\n---\n\n")
    
    print(f"\nSaved:")
    print(f"  - {output_file} (JSON for vector DB)")
    print(f"  - {md_output} (Markdown for reading)")
    print(f"\nTotal: {len(documents)} videos, {sum(d['word_count'] for d in documents):,} words")

if __name__ == '__main__':
    combine_transcripts('transcripts_clean', 'sara_knowledge_base.json')
```

## Step 5: If Auto-Captions Are Bad Quality

If YouTube's auto-captions are garbage (heavy accent, technical terms wrong), use Whisper:

```bash
# Download audio only
yt-dlp \
  -x \
  --audio-format mp3 \
  -o "audio/%(upload_date)s-%(title)s.%(ext)s" \
  "https://www.youtube.com/@dealmakerseta"

# Transcribe with Whisper (medium model is good balance of speed/quality)
# This will take a while - roughly real-time on CPU, faster on GPU
whisper audio/*.mp3 --model medium --output_dir transcripts_whisper --output_format txt
```

## Directory Structure After Running

```
project/
├── video_urls.txt              # List of all video URLs
├── transcripts/                # Raw VTT files from YouTube
│   ├── 20240115-Video Title.en.vtt
│   └── ...
├── transcripts_clean/          # Cleaned text files
│   ├── 20240115-Video Title.txt
│   └── ...
├── sara_knowledge_base.json    # Combined JSON (for vector DB)
├── sara_knowledge_base.md      # Combined Markdown (for reading)
└── audio/                      # (Optional) Audio files if using Whisper
```

## Adding the Book

For the book (assuming PDF):

```bash
# Install pdf extraction
pip install pymupdf

# Extract text from PDF
python -c "
import fitz
doc = fitz.open('book.pdf')
text = ''
for page in doc:
    text += page.get_text()
with open('book_content.txt', 'w') as f:
    f.write(text)
print(f'Extracted {len(text)} characters')
"
```

Then add to the knowledge base JSON manually or create a separate document.

## Next Steps (After You Have All Transcripts)

1. **Quick win**: Upload `sara_knowledge_base.md` + book to CustomGPT.ai or Chatbase
2. **Better**: Load JSON into Supabase pgvector or Pinecone
3. **Best**: Build custom RAG with n8n + vector DB + Claude/GPT-4

---

## One-Liner to Run Everything

```bash
# Full pipeline (after installing prerequisites)
yt-dlp --write-auto-sub --sub-lang en --skip-download --sub-format vtt \
  -o "transcripts/%(upload_date)s-%(title)s.%(ext)s" \
  "https://www.youtube.com/@dealmakerseta" && \
python clean_transcripts.py && \
python combine_transcripts.py
```

Estimated time: 5-10 minutes depending on number of videos (downloading captions is fast).
