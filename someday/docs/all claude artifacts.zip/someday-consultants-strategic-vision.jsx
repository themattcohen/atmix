import React from 'react';

export default function StrategicVision() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-slate-900 text-white py-16 px-8">
        <div className="max-w-3xl mx-auto">
          <p className="text-slate-400 text-sm uppercase tracking-widest mb-4">Someday Consultants</p>
          <h1 className="text-4xl font-light mb-4">Building a Brokerage, Not a Job</h1>
          <p className="text-xl text-slate-300 font-light">Strategic vision for scaling accounting firm M&A</p>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-8 py-12">
        
        {/* The Opportunity */}
        <section className="mb-16">
          <h2 className="text-2xl font-semibold text-slate-800 mb-6">The Opportunity</h2>
          <p className="text-slate-600 mb-4 leading-relaxed">
            The accounting firm M&A market is underserved by knowledgeable brokers. Most business brokers treat accounting practices like any other small business, missing the nuances of client retention, staff transition, service mix valuation, and the regulatory considerations that actually determine deal success.
          </p>
          <p className="text-slate-600 mb-4 leading-relaxed">
            Sara has closed over 100 deals as transaction counsel in two years. That depth of experience, combined with niche focus, creates a significant competitive advantage. The expertise exists. The reputation exists. The content creation muscle exists.
          </p>
          <p className="text-slate-700 font-medium">
            What's missing is the operational infrastructure to turn that expertise into a scalable brokerage business.
          </p>
        </section>

        {/* The Constraint */}
        <section className="mb-16 bg-white rounded-lg p-8 border border-slate-200">
          <h2 className="text-2xl font-semibold text-slate-800 mb-6">The Constraint</h2>
          <p className="text-slate-600 mb-4 leading-relaxed">
            Running a law firm means selling time. Every hour spent on brokerage outreach is an hour not billed to legal clients. This creates a ceiling: growth requires more of Sara's hours, but those hours are already allocated.
          </p>
          <p className="text-slate-600 mb-4 leading-relaxed">
            The current state reflects this reality:
          </p>
          <ul className="text-slate-600 mb-4 space-y-2">
            <li className="flex items-start">
              <span className="text-slate-400 mr-3">•</span>
              <span>Videos are being recorded, but not systematically repurposed</span>
            </li>
            <li className="flex items-start">
              <span className="text-slate-400 mr-3">•</span>
              <span>Information exists, but scattered across systems</span>
            </li>
            <li className="flex items-start">
              <span className="text-slate-400 mr-3">•</span>
              <span>No capacity for aggressive outbound prospecting</span>
            </li>
            <li className="flex items-start">
              <span className="text-slate-400 mr-3">•</span>
              <span>Two brokerage deals closed, but no repeatable engine</span>
            </li>
          </ul>
          <p className="text-slate-700 font-medium">
            The bottleneck isn't knowledge or credibility. It's bandwidth.
          </p>
        </section>

        {/* The Strategy */}
        <section className="mb-16">
          <h2 className="text-2xl font-semibold text-slate-800 mb-6">The Strategy</h2>
          <p className="text-slate-600 mb-6 leading-relaxed">
            Build systems that multiply reach without multiplying hours. Sara's time should be spent on high-value activities: seller conversations, deal negotiation, relationship building. Everything else should either be automated or handled operationally.
          </p>
          
          <div className="grid gap-6">
            <div className="bg-slate-100 rounded-lg p-6">
              <h3 className="font-semibold text-slate-800 mb-2">Content Becomes the Outbound</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Every video Sara records gets transformed into blog posts, newsletter content, LinkedIn posts, and short-form clips. One hour of recording becomes a week of multi-channel presence. The content machine runs continuously while Sara focuses elsewhere.
              </p>
            </div>
            
            <div className="bg-slate-100 rounded-lg p-6">
              <h3 className="font-semibold text-slate-800 mb-2">Systems Capture and Nurture</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Leads flow into a single source of truth. Marketing automation handles nurture sequences. When someone is ready to talk, they surface to the top. No leads fall through cracks. No manual tracking in spreadsheets.
              </p>
            </div>
            
            <div className="bg-slate-100 rounded-lg p-6">
              <h3 className="font-semibold text-slate-800 mb-2">Data Creates Defensibility</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                Every closed deal feeds a proprietary database of actual transaction terms, multiples, and deal structures. Over time, this becomes a genuine market intelligence asset that no competitor can replicate. The data moat compounds.
              </p>
            </div>
          </div>
        </section>

        {/* How We Built It */}
        <section className="mb-16 bg-white rounded-lg p-8 border border-slate-200">
          <h2 className="text-2xl font-semibold text-slate-800 mb-6">How We're Building It</h2>
          <p className="text-slate-600 mb-6 leading-relaxed">
            The tech stack follows a simple principle: one source of truth, with everything else as satellites. No duplicate data entry. No reconciling spreadsheets. Information flows in, gets structured, and becomes actionable.
          </p>
          
          <div className="space-y-6">
            <div className="border-l-4 border-slate-300 pl-4">
              <h3 className="font-semibold text-slate-800 mb-1">Centralized Data</h3>
              <p className="text-slate-600 text-sm">
                All contacts, listings, deals, and activities live in one structured database. Buyer criteria, seller motivations, deal terms, marketing attribution - captured consistently so it can be analyzed and acted upon.
              </p>
            </div>
            
            <div className="border-l-4 border-slate-300 pl-4">
              <h3 className="font-semibold text-slate-800 mb-1">Marketing Automation</h3>
              <p className="text-slate-600 text-sm">
                Forms, email sequences, calendar booking, and pipeline management happen automatically. Leads are tagged by source, nurtured based on behavior, and surfaced when they show buying signals.
              </p>
            </div>
            
            <div className="border-l-4 border-slate-300 pl-4">
              <h3 className="font-semibold text-slate-800 mb-1">Content Multiplication</h3>
              <p className="text-slate-600 text-sm">
                AI-powered tools transform long-form video into ready-to-publish assets. Blog posts, social content, newsletter sections, and video clips are generated from each recording with minimal editing required.
              </p>
            </div>
            
            <div className="border-l-4 border-slate-300 pl-4">
              <h3 className="font-semibold text-slate-800 mb-1">Intelligent Orchestration</h3>
              <p className="text-slate-600 text-sm">
                Custom automation syncs data between systems, generates reports on demand, and handles repetitive tasks. The systems talk to each other without manual intervention.
              </p>
            </div>
          </div>
        </section>

        {/* Why This Approach */}
        <section className="mb-16">
          <h2 className="text-2xl font-semibold text-slate-800 mb-6">Why This Approach</h2>
          
          <div className="space-y-8">
            <div>
              <h3 className="font-semibold text-slate-700 mb-2">Ownership over rental</h3>
              <p className="text-slate-600 leading-relaxed">
                We're building on platforms where we own the data and control the structure. No vendor lock-in. No paying for seats we don't need. No limitations on how we organize information. The database is ours, the logic is ours, the data is ours.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-slate-700 mb-2">Flexibility over features</h3>
              <p className="text-slate-600 leading-relaxed">
                Purpose-built brokerage software exists, but it's designed for general business brokers. Our data model captures what matters for accounting firm transactions specifically: service mix, client concentration, staff transition terms, technology stack. We can track what actually drives value in this niche.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-slate-700 mb-2">Compounding over linear</h3>
              <p className="text-slate-600 leading-relaxed">
                Every piece of content created becomes a permanent asset that generates leads indefinitely. Every deal closed adds to a proprietary dataset. Every process documented can be delegated. The work done today continues paying dividends.
              </p>
            </div>
          </div>
        </section>

        {/* What This Enables */}
        <section className="mb-16 bg-slate-900 text-white rounded-lg p-8">
          <h2 className="text-2xl font-semibold mb-6">What This Enables</h2>
          
          <div className="space-y-6">
            <div className="flex items-start">
              <div className="bg-slate-700 rounded-full w-8 h-8 flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                <span className="text-sm font-semibold">1</span>
              </div>
              <div>
                <h3 className="font-semibold mb-1">Consistent deal flow without cold outreach</h3>
                <p className="text-slate-300 text-sm">Content and SEO generate inbound. Nurture sequences warm leads over time. Sellers come to us positioned as the authority.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-slate-700 rounded-full w-8 h-8 flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                <span className="text-sm font-semibold">2</span>
              </div>
              <div>
                <h3 className="font-semibold mb-1">Market intelligence as a product</h3>
                <p className="text-slate-300 text-sm">With enough closed deal data, we can publish authoritative reports on accounting firm valuations. This creates credibility, attracts leads, and could become a standalone revenue stream.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-slate-700 rounded-full w-8 h-8 flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                <span className="text-sm font-semibold">3</span>
              </div>
              <div>
                <h3 className="font-semibold mb-1">A business with enterprise value</h3>
                <p className="text-slate-300 text-sm">Documented processes, proprietary data, recurring lead generation, and brand equity create something that has value beyond individual deal commissions. This is a business that could be sold, not just a practice.</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="bg-slate-700 rounded-full w-8 h-8 flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                <span className="text-sm font-semibold">4</span>
              </div>
              <div>
                <h3 className="font-semibold mb-1">Sara's time protected</h3>
                <p className="text-slate-300 text-sm">The operational infrastructure handles lead generation, nurture, scheduling, and data management. Sara's hours are reserved for the activities only she can do: building relationships and closing deals.</p>
              </div>
            </div>
          </div>
        </section>

        {/* The Path Forward */}
        <section className="mb-16">
          <h2 className="text-2xl font-semibold text-slate-800 mb-6">The Path Forward</h2>
          <p className="text-slate-600 mb-6 leading-relaxed">
            The foundation is designed and ready to implement. The immediate focus:
          </p>
          
          <div className="bg-white rounded-lg border border-slate-200 divide-y divide-slate-200">
            <div className="p-4">
              <div className="flex items-center">
                <span className="bg-slate-100 text-slate-600 text-xs font-semibold px-2 py-1 rounded mr-3">NOW</span>
                <span className="text-slate-700">Stand up the central database and connect marketing automation</span>
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-center">
                <span className="bg-slate-100 text-slate-600 text-xs font-semibold px-2 py-1 rounded mr-3">NEXT</span>
                <span className="text-slate-700">Activate the content repurposing engine from existing videos</span>
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-center">
                <span className="bg-slate-100 text-slate-600 text-xs font-semibold px-2 py-1 rounded mr-3">THEN</span>
                <span className="text-slate-700">Layer in outbound channels as inbound stabilizes</span>
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-center">
                <span className="bg-slate-100 text-slate-600 text-xs font-semibold px-2 py-1 rounded mr-3">ONGOING</span>
                <span className="text-slate-700">Capture deal data, build the market intelligence asset</span>
              </div>
            </div>
          </div>
        </section>

        {/* Closing */}
        <section className="text-center py-8 border-t border-slate-200">
          <p className="text-slate-500 text-sm mb-2">Prepared by</p>
          <p className="text-slate-800 font-semibold">Matt, COO</p>
          <p className="text-slate-500 text-sm">Someday Consultants</p>
        </section>

      </main>
    </div>
  );
}
