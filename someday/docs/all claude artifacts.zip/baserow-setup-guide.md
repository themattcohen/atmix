# Accounting Firm Brokerage CRM - Baserow Setup Guide

## Overview

This document outlines the complete data architecture for an accounting firm brokerage CRM built on Baserow. The system tracks buyers, sellers, listings, deals, and provides the structured data needed for market reports and analytics.

---

## Quick Start

### Option 1: Baserow Cloud (Fastest)
1. Go to [baserow.io](https://baserow.io) and create a free account
2. Create a new database called "Accounting Firm Brokerage"
3. Manually create tables following the schema below
4. Set up the linked relationships between tables

### Option 2: Self-Hosted (Most Control)
```bash
docker run -d \
  --name baserow \
  -v baserow_data:/baserow/data/ \
  -p 80:80 \
  -p 443:443 \
  baserow/baserow:latest
```
Then access at `http://localhost` and create your database.

---

## Tables Overview

| Table | Purpose | Key Fields |
|-------|---------|------------|
| **Contacts** | Base entity for all people | Name, Email, Type, Status, Source |
| **Buyer Profiles** | Acquisition criteria | Revenue range, Geo, Services, Timeline, Funding |
| **Seller Profiles** | Seller motivations | Reason, Timeline, Deal structure prefs |
| **Listings** | Firms for sale | Financials, Services mix, Tech stack, Geography |
| **Deals** | Active transactions | Stage, Key dates, Outcome |
| **Deal Terms** | THE GOLD for analytics | Price, Multiples, Structure, Financing, Transition |
| **Activities** | All touchpoints | Type, Date, Outcome, GHL sync |
| **Documents** | NDAs, LOIs, etc. | Type, Status, Dates |
| **Marketing Attribution** | Track what's working | Source, Campaign, Conversion dates |

---

## Table Relationships

```
Contacts (1) -----> (0..1) Buyer Profiles
    |
    +-------------> (0..1) Seller Profiles
                              |
                              v
                    (1) Seller Profiles -----> (N) Listings
                                                    |
                                                    v
Buyer Profiles (N) <---- Deals ----> (1) Listings
                            |
                            v
                    (1) Deal Terms

Contacts (1) -----> (N) Activities
Contacts (1) -----> (1) Marketing Attribution
```

---

## Critical Setup Steps

### 1. Create Tables in This Order
(To handle linked fields properly)

1. Contacts
2. Buyer Profiles (link to Contacts)
3. Seller Profiles (link to Contacts)
4. Listings (link to Seller Profiles)
5. Deals (link to Buyer Profiles + Listings)
6. Deal Terms (link to Deals)
7. Activities (link to Contacts + Deals)
8. Documents (link to Deals + Listings + Contacts)
9. Marketing Attribution (link to Contacts)

### 2. Set Up Key Views

**Contacts Table:**
- "Active Buyers" - Filter: Contact Type = Buyer AND Status = Active
- "Active Sellers" - Filter: Contact Type = Seller AND Status = Active
- "Needs Followup" - Filter: Next Followup Date <= Today

**Listings Table:**
- "Active Listings" - Filter: Listing Status = Active
- "Pipeline" - Kanban view grouped by Listing Status

**Deals Table:**
- "Active Pipeline" - Kanban view grouped by Stage
- "Closing This Month" - Filter: Target Close Date in current month

**Deal Terms Table:**
- "Closed Deal Terms" - Filter: Terms Stage = Actual at Close
  - THIS IS YOUR ANALYTICS GOLD MINE

### 3. Set Up Automations

Baserow has built-in automations. Set up:

1. **New Contact Alert**
   - Trigger: New row in Contacts
   - Action: Send notification / webhook to Slack

2. **Deal Stage Change**
   - Trigger: Field update on Deals.Stage
   - Action: Update Stage Entered Date, Send notification

3. **Followup Reminder**
   - Trigger: Next Followup Date = Today
   - Action: Send email/notification

---

## GHL Integration

### Sync Contacts: GHL -> Baserow

Use n8n, Make, or Zapier:

1. **Trigger:** New contact in GHL
2. **Action:** Create row in Baserow Contacts table
3. **Map fields:**
   - GHL First Name -> Baserow First Name
   - GHL Email -> Baserow Email
   - GHL Phone -> Baserow Phone
   - GHL Tags -> Baserow Tags
   - GHL Contact ID -> Baserow GHL Contact ID

### Sync Activities: GHL -> Baserow

1. **Trigger:** Email sent/received, Call logged, Form submitted in GHL
2. **Action:** Create row in Baserow Activities table
3. **Lookup:** Find Contact by GHL Contact ID
4. **Map:** Activity type, date, description

### Sync Back: Baserow -> GHL

1. **Trigger:** Contact status change in Baserow
2. **Action:** Update GHL contact tags/pipeline stage

---

## Marketing Attribution Setup

### Capture UTMs in GHL Forms

Add hidden fields to your GHL forms:
- `utm_source`
- `utm_medium`
- `utm_campaign`
- `landing_page`

Use Attributer.io or custom JS to populate these.

### Flow:
1. Visitor lands on site with UTM params
2. Fills out form in GHL
3. n8n/Zapier syncs to Baserow Contacts + Marketing Attribution
4. Track: Lead -> Deal -> Closed conversion by source

---

## Analytics Views (For Market Reports)

Once you have 20+ closed deals with Deal Terms data, you can generate:

### Multiples Analysis
```
Average Revenue Multiple = AVG(Deal Terms.Multiple of Revenue) 
WHERE Terms Stage = "Actual at Close"

Group by: State, Firm Size Bracket, Service Mix
```

### Deal Structure Insights
```
Average Cash at Close % = AVG(Deal Terms.Cash at Close %)
Earnout Prevalence = COUNT(Earnout Amount > 0) / COUNT(*)
```

### Export to Looker Studio
Use Coupler.io or Windsor.ai to sync Baserow -> Looker Studio for visualization.

---

## Field Naming Conventions

- Use clear, readable names (Baserow handles spaces well)
- Prefix section dividers with "---" (these are just visual helpers)
- Use consistent naming: "X at Close", "X TTM", "X %"
- Boolean fields: "Is X", "Has X", "Includes X"

---

## Data Entry Best Practices

### Critical: Use Dropdowns, Not Free Text
The analytics value comes from consistent, structured data. Always use:
- Single select for categorical data
- Multiple select for multi-value categories
- Numbers for anything quantitative

### For Deal Terms (Your Analytics Gold)
When a deal closes, create a Deal Terms record with:
- Terms Stage = "Actual at Close"
- Fill in ALL pricing, structure, financing, and transition fields
- These become your market report data points

---

## Sample Queries for Market Reports

### Average Multiple by State (Last 12 Months)
Filter Deal Terms where:
- Terms Stage = "Actual at Close"
- Created Date >= 12 months ago

Group by: Listing -> State
Calculate: AVG(Multiple of Revenue), AVG(Multiple of SDE)

### Deal Structure Breakdown
Filter Deal Terms where:
- Terms Stage = "Actual at Close"

Calculate:
- % with Earnout = COUNT(Earnout Amount > 0) / total
- % with Seller Note = COUNT(Seller Note Amount > 0) / total
- AVG Cash at Close %

### Buyer Demographics
Filter Buyer Profiles linked to Closed Deals:
- Buyer Type distribution
- Funding Source distribution
- First Time vs Serial Acquirer success rates

---

## Maintenance

### Weekly
- Review "Needs Followup" view
- Update deal stages
- Check for stale "Active" contacts

### Monthly
- Export Deal Terms for trend analysis
- Review marketing attribution - what's working?
- Clean up any free-text fields that should be dropdowns

### Quarterly
- Generate market report from Deal Terms data
- Review and refine automation workflows
- Archive old closed/lost deals if needed

---

## Questions?

The JSON schema file (`baserow-schema.json`) contains the complete field definitions for programmatic setup or reference.
